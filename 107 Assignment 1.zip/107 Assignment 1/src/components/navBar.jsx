import React, { Component } from 'react'; //imrc
import "./navBar.css"

//cc
class NavBar extends Component {
    state = {  }
    render() { 
        //JSX syntax
        return ( <div className="navbar-page" ><h6>Put the menu here</h6></div>  );
    }
}
 
export default NavBar;